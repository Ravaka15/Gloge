<?php

namespace App\Models;
use App\Models\Produit;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cite extends Model
{
    use HasFactory;

    protected $primaryKey = 'idcite';
    
    protected $fillable = [
        'localisation',
    ];
    public function produits()
    {
        return $this->hasMany(Produit::class);
    }
    public function users()
    {
        return $this->hasMany(User::class);
    }
}
