<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produit extends Model
{
    use HasFactory;
    protected $fillable = [
        'label',
        'type',
        'disponible',
        'details',
        'prix',
        'image',
        'cite_id'
    ];
    public function cite()
    {
        return $this->belongsTo(Cite::class);
    }
}
