<?php

namespace App\Http\Controllers;

use App\Http\Resources\CiteCollection;
use App\Models\Cite;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class CiteController extends Controller
{
    // public function addcite(Request $request)
    // {
    //     return Cite::create([
    //         'localisation' => $request->input('localisation'),
    //     ]);
    // }

     public function getCite()
    {
        $cites = Cite::all();
        return new CiteCollection($cites);
    }

    public function addcite(Request $request)
    {
        $cite = new Cite([
            'localisation' => $request->input('localisation'),
        ]);

        $cite->save();

        return response()->json(['message' => 'Cite ajoutée']);
    }

    public function updateCite(Request $request, $idcite)
    {
        $cite = Cite::find($idcite);

        if ($cite) {
            $cite->localisation = $request->input('localisation');
            $cite->save();

            return response()->json(['message' => 'Cite modifiée']);
        }

        return response()->json(['message' => 'Cite non trouvée'], 404);
    }

    public function deleteCite($idcite)
    {
        $cite = Cite::find($idcite);

        if ($cite) {
            $cite->delete();

            return response()->json(['message' => 'Cite supprimée']);
        }

        return response()->json(['message' => 'Cite non trouvée'], 404);
    }

}
