<?php

namespace App\Http\Controllers;

use App\Models\Achat;
use App\Models\Produit;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class AchatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $data = Achat::create([
            'type' => $request->input('type'),
            'client_id' => $request->input('client_id'),
            'produit_id' => $request->input('produit_id'),
        ]);

        return response($data, Response::HTTP_CREATED);
    }



    public function countAchats()
    {
        $count = Achat::count();
        return response()->json(['count' => $count]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Achat  $achat
     * @return \Illuminate\Http\Response
     */
    public function showsall()
    {
         return DB::table('achats')
        ->join('clients', 'achats.client_id', '=', 'clients.idclient')
        ->join('produits', 'achats.produit_id', '=', 'produits.id')
        ->select('achats.*', 'clients.*', 'produits.*')
        ->get();
    }

    public function showsalldisponible()
{
     return DB::table('achats')
    ->join('clients', 'achats.client_id', '=', 'clients.idclient')
    ->join('produits', 'achats.produit_id', '=', 'produits.id')
    
    ->get();
}
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Achat  $achat
     * @return \Illuminate\Http\Response
     */
    public function edit(Achat $achat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Achat  $achat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Achat $achat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Achat  $achat
     * @return \Illuminate\Http\Response
     */
    public function showAchat($id)
    {
        $achat = Achat::find($id);
        return response()->json($achat);
    }


}
