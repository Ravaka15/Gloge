<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AgenceController extends Controller
{
      // Afficher tous les clients
      public function getAgences()
      {
          return DB::table('Users')
          ->join('cites','cites.id',"=",'users.cite_id')
          ->get();;
      }
  
      // Modifier un agence
      public function updateAgences(Request $request, $id)
      {
          $user = User::find($id);
          $user->name = $request->input('name');
          $user->phone = $request->input('phone');
          $user->email = $request->input('email');
          $user->save();
          return $user;
      }
  
      public function deleteAgences($id)
      {
          $user = User::find($id);
          if (!$user) {
              return response()->json(['message' => 'Agence introuvable'], 404);
          }
          $user->delete();
          return response()->json(['message' => 'Agence supprimé']);
      }

       // Compter le nombre de Agences
    public function countAgences()
    {
        $count = User::count();
        return response()->json(['count' => $count]);
    }
}
