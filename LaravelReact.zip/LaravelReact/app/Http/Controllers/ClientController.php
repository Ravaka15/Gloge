<?php

namespace App\Http\Controllers;


use App\Models\Client;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    public function addclient(Request $request)
    {
        return Client::create([
            'nameclient' => $request->input('nameclient'),
            'lastnameclient' => $request->input('lastnameclient'),
            'sexeclient' => $request->input('sexeclient'),
            'birthclient' => $request->input('birthclient'),
            'adressclient' => $request->input('adressclient'),
            'phoneclient' => $request->input('phoneclient'),
            'emailclient' => $request->input('emailclient')
        ]);
    }

    // Afficher tous les clients
    public function getClients()
    {
        return Client::all();
    }

    // Modifier un client
    public function updateClient(Request $request, $idclient)
    {
        $client = Client::find($idclient);
        $client->nameclient = $request->input('nameclient');
        $client->lastnameclient = $request->input('lastnameclient');
        $client->sexeclient = $request->input('sexeclient');
        $client->birthclient = $request->input('birthclient');
        $client->adressclient = $request->input('adressclient');
        $client->phoneclient = $request->input('phoneclient');
        $client->emailclient = $request->input('emailclient');
        $client->save();
        return $client;
    }

    public function deleteClient($idclient)
    {
        $client = Client::find($idclient);
        if (!$client) {
            return response()->json(['message' => 'Client introuvable'], 404);
        }
        $client->delete();
        return response()->json(['message' => 'Client supprimé']);
    }

    public function searchClients(Request $request)
    {
    $searchTerm = $request->input('search');

    $clients = Client::where('nameclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('lastnameclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('sexeclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('birthclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('adressclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('phoneclient', 'LIKE', '%'.$searchTerm.'%')
                    ->orWhere('emailclient', 'LIKE', '%'.$searchTerm.'%')
                    ->get();

    return response()->json(['clients' => $clients]);
    }

    // Compter le nombre de clients
    public function countClients()
    {
        $count = Client::count();
        return response()->json(['count' => $count]);
    }
}
