<?php

namespace App\Http\Controllers;

use App\Http\Resources\ProduitCollection;
use App\Models\Produit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

class ProduitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sql = Produit::with('cite')->get();
        
        return new ProduitCollection(Produit::with('cite')->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $file = $request->file('image');
        $name = time().'.'.$file->getClientOriginalExtension();
        $file->move('images/',$name);
      
        $data = Produit::create([
            'label' => $request->input('label'),
            'type' => $request->input('type'),
            'prix' => $request->input('prix'),
            'details' => $request->input('details'),
            'disponible' => $request->input('disponible'),
            'image' => $name,
            'cite_id' => $request->input('cite_id'),
        ]);

        return response($data, Response::HTTP_CREATED);

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Produit  $produit
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $produit = Produit::find($id);
        return response()->json($produit);
    }
    public function showsall()
    {
        return DB::table('produits')
        ->join('cites','cites.id',"=",'produits.cite_id')
        ->get();
    }
    public function showsdisponible()
    {
        return DB::table('produits')
        ->join('cites','cites.id',"=",'produits.cite_id')
        ->select('produits.*', 'cites.*')
        ->where('produits.disponible', '=', '1') 
        ->get();
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Produit  $produit
     * @return \Illuminate\Http\Response
     */
     // Modifier un produit 
     public function updateProduit(Request $request, $id)
     {
         $produit = Produit::find($id);
         $produit->disponible = $request->input('disponible');
         $produit->save();
         return $produit;
     }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Produit  $produit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Produit $produit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Produit  $produit
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $produit = Produit::find($id);
    if (!$produit) {
        return response()->json(['error' => 'Produit non trouvé.'], 404);
    }
    $produit->delete();
    return response()->json(['message' => 'Produit supprimé avec succès.'], 200);
    }

    public function countProduits()
    {
        $count = Produit::count();
        return response()->json(['count' => $count]);
    }
}
