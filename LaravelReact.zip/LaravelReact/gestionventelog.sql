-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 01, 2023 at 03:16 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestionventelog`
--

-- --------------------------------------------------------

--
-- Table structure for table `achats`
--

DROP TABLE IF EXISTS `achats`;
CREATE TABLE IF NOT EXISTS `achats` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `produit_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `achats_produit_id_foreign` (`produit_id`),
  KEY `achats_client_id_foreign` (`client_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cites`
--

DROP TABLE IF EXISTS `cites`;
CREATE TABLE IF NOT EXISTS `cites` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `localisation` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cites`
--

INSERT INTO `cites` (`id`, `localisation`, `created_at`, `updated_at`) VALUES
(1, 'Andrainjato', '2023-05-01 12:04:31', '2023-05-01 12:04:31'),
(2, 'Mahazengy', '2023-05-01 12:04:45', '2023-05-01 12:04:45'),
(3, 'Antarandolo', '2023-05-01 12:04:58', '2023-05-01 12:04:58');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `idclient` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nameclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastnameclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexeclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adressclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phoneclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailclient` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`idclient`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`idclient`, `nameclient`, `lastnameclient`, `sexeclient`, `birthclient`, `adressclient`, `phoneclient`, `emailclient`, `created_at`, `updated_at`) VALUES
(1, 'RAKOTONDRASOA', 'Nandrianina', 'Masculin', '2000-05-03', 'FANDRIANA', '0348904076', 'nandrianina@gmail.com', '2023-05-01 11:58:05', '2023-05-01 11:58:05'),
(2, 'RAVAKA', 'Minoharisoa', 'Feminin', '2002-05-03', 'AMBOSITRA', '0348904076', 'ravaka@gmail.com', '2023-05-01 11:58:47', '2023-05-01 11:58:47');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(3, '2023_04_12_190403_create_clients_table', 1),
(4, '2023_04_12_213112_produit_table', 1),
(5, '2023_04_12_223048_create_cites_table', 1),
(6, '2023_04_15_044923_achat', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `label` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disponible` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cite_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produits_cite_id_foreign` (`cite_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `produits`
--

INSERT INTO `produits` (`id`, `label`, `type`, `prix`, `disponible`, `details`, `image`, `cite_id`, `created_at`, `updated_at`) VALUES
(1, 'Villa 3 étages', 'Logement', '10000000', '1', 'Avec douche et WC\r\nAvec mur', '1682953592.jpg', 1, '2023-05-01 12:06:32', '2023-05-01 12:06:32'),
(2, 'Maison en beton', 'Logement', '2000000', '1', 'Avec WC et douche', '1682953715.jpg', 1, '2023-05-01 12:08:35', '2023-05-01 12:08:35'),
(3, 'Maison en bois', 'Logement', '2000000', '1', 'Avec WC et douche en securité', '1682953764.jpg', 3, '2023-05-01 12:09:25', '2023-05-01 12:09:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cite_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_cite_id_foreign` (`cite_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `cite_id`, `created_at`, `updated_at`) VALUES
(1, 'Avotra', '0348923525', 'avotra@gmail.com', '$2y$10$RN5M05gdM1KP4oilZ7FbV.FXKSdVMONf9u0b18fPeEKvVZmtnBi2m', 1, '2023-05-01 12:10:24', '2023-05-01 12:10:24'),
(2, 'Vonjy', '0348923525', 'vonjy@gmail.com', '$2y$10$zFf/A04Jb3h018BQQU0TY.xjSLcCJ/bA6EAkv/5gJ.uT3s9vVCaNi', 2, '2023-05-01 12:11:09', '2023-05-01 12:11:09');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
