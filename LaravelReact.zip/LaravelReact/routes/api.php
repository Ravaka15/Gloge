<?php

use App\Http\Controllers\AchatController;
use App\Http\Controllers\ProduitController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('registre', [\App\Http\Controllers\AuthController::class, 'registre']);
Route::post('login', [\App\Http\Controllers\AuthController::class, 'login']);
////Produit
Route::post('produit', [\App\Http\Controllers\ProduitController::class, 'store']);
Route::get('produit', [\App\Http\Controllers\ProduitController::class, 'index']);
Route::get('produit/{id}', [\App\Http\Controllers\ProduitController::class, 'show']);
Route::put('produit/{id}', [\App\Http\Controllers\ProduitController::class, 'updateProduit']);
Route::delete('produit/{id}', [ProduitController::class, 'destroy']);
Route::get('produits', [ProduitController::class, 'showsall']);
Route::get('produitsdispo', [\App\Http\Controllers\ProduitController::class, 'showsdisponible']);
Route::get('/produits/count', [\App\Http\Controllers\ProduitController::class, 'countProduits']);
Route::get('produitscendu', [\App\Http\Controllers\ProduitController::class, 'showsvendu']);
///CRUD Client
Route::post('addclient', [\App\Http\Controllers\ClientController::class, 'addclient']);
Route::get('clients', [\App\Http\Controllers\ClientController::class, 'getClients']);
Route::put('clients/{idclient}', [\App\Http\Controllers\ClientController::class, 'updateClient']);
Route::delete('clients/{idclient}', [\App\Http\Controllers\ClientController::class, 'deleteClient']);
Route::get('/clients/search', [\App\Http\Controllers\ClientController::class, 'searchClients']);
Route::get('/clients/count', [\App\Http\Controllers\ClientController::class, 'countClients']);
///CRUD Cite
Route::post('addcite', [\App\Http\Controllers\CiteController::class, 'addcite']);
Route::get('cites', [\App\Http\Controllers\CiteController::class, 'getCite']);
Route::put('cites/{idcite}', [\App\Http\Controllers\CiteController::class, 'updateCite']);
Route::delete('cites/{idcite}', [\App\Http\Controllers\CiteController::class, 'deleteCite']);

///CRUD Agences
Route::get('users', [\App\Http\Controllers\AgenceController::class, 'getAgences']);
Route::put('users/{id}', [\App\Http\Controllers\AgenceController::class, 'updateAgences']);
Route::delete('users/{id}', [\App\Http\Controllers\AgenceController::class, 'deleteAgences']);
Route::get('/users/count', [\App\Http\Controllers\AgenceController::class, 'countAgences']);
///crud achat
Route::post('achat', [\App\Http\Controllers\AchatController::class, 'create']);
Route::get('achat', [\App\Http\Controllers\AchatController::class, 'showsall']);
Route::get('achatdisponible', [\App\Http\Controllers\AchatController::class, 'showsalldisponible']);
Route::get('achat/{id}', [\App\Http\Controllers\AchatController::class, 'showAchat']);
Route::get('/achats/count', [\App\Http\Controllers\AchatController::class, 'countAchats']);

Route::middleware('auth:sanctum')->group(function (){
    Route::get('user', [\App\Http\Controllers\AuthController::class, 'user']);
    Route::post('logout', [\App\Http\Controllers\AuthController::class, 'logout']);
});